/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosc241_project3_ddnelson0;
import java.util.*;
import java.io.*;
/**
 * 
 *
 * @author davon
 */
public class Test {
    public static void main(String[] args) throws IOException{
        MySet mySet1 = new MySet();
        MySet mySet2 = new MySet();
        
        
        Scanner sc = new Scanner(new File("input.txt")); //inialize scanner
       
        
        File dir = new File("Output");//create output folder 
        dir.mkdir();
        PrintStream ps = new PrintStream(new File("Output/output.txt"));
        
        //Splitiing first line of input
            String text = sc.nextLine(); 
            String[] test = text.split(" "); 
            for(String a: test){
               Integer i = Integer.valueOf(a); 
             mySet1.add(i); 
            }
        
            
            //Splitting second line of input
            text = sc.nextLine();
            test = text.split(" ");
            for(String a: test){
               Integer i = Integer.valueOf(a);
             mySet2.add(i);
            }
            
      //printing to output file 
         ps.println("MySet mySet1 is " + mySet1);
         ps.println("Cardinality of mySet1 is " + mySet1.cardinality());
         ps.println();
         ps.println("MySet mySet2 is "+ mySet2);
         ps.println("Cardinality of mySet2 is "+ mySet2.cardinality());
         ps.println();
         ps.println("Intersection set is " + mySet1.intersection(mySet2));
         ps.println();
         ps.println("Symmetric difference set is " + mySet1.symmetricDifference(mySet2));
         ps.println();
         ps.println("Union set is " + mySet1.union(mySet2));
   
   
    }
    

}
