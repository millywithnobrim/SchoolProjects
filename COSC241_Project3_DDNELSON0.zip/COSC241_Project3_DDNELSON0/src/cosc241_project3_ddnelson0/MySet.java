/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosc241_project3_ddnelson0;
import java.util.*;
/**
 *
 * @author davon
 */
public class MySet {

    
    private Collection<Integer> collection;

   public MySet(){
       this.collection = new HashSet<>(); //makes collection = to HashSet
   }
    public MySet(Collection<Integer> collection){
         this.collection = collection;
         for( Integer x: collection){
             add(x);// call the method add as seen below 
         }
    }
    
   public void add(int e){
       if(collection.contains(e)){  // searches for elemement e in cthe collection if true do nothing
       }else{//if false  
           collection.add(e);//add element e
       }
   }
        
       
       
   
    public int cardinality(){
      int cardinality =  collection.size();
      return cardinality;
    }
    
    public Collection<Integer> clone(){
       Collection <Integer> clone = new HashSet<>();//clone becomes its own set
       clone.addAll(collection);//adds the values stored in collection while keeping both seperate
        return clone;
    }
    
    public MySet complement(MySet b){
       Collection <Integer> temp1 = this.clone();
       Collection <Integer> temp2 = b.clone();
       temp1.removeAll(temp2);
       MySet x = new MySet(temp1);
       return x;
        
    }
    
     public MySet intersection(MySet b){ 
        Collection <Integer> temp1 = this.clone();
        Collection <Integer> temp2 = b.clone();
        temp1.retainAll(temp2);
        MySet x = new MySet(temp1);
        return x;
     
     }
     
      public MySet union(MySet b){
        Collection <Integer> temp1 = this.clone();
        Collection <Integer> temp2 = b.clone();
        temp1.addAll(temp2);
        MySet x = new MySet(temp1);
        return x;
      }
      
       public MySet symmetricDifference(MySet b){
      Collection <Integer> temp1 = this.clone();
      Collection <Integer> temp3 = this.clone();//same as value as temp1 
      Collection <Integer> temp2 = b.clone();
     temp1.removeAll(temp2);// when called it changes temp1 from the original set which is why temp3 is created  
     temp2.removeAll(temp3);// represents complement of temp2 and the values stored in temp3 which is the same as temp 1
     temp1.addAll(temp2);// union of both complements 
       
        MySet x= new MySet(temp1);
        return x;
       }
       public String toString(){
       String result = collection.toString();
       return result;
    }
 
}
